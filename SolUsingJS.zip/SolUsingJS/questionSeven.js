/**Q7: Write a program in any language which replicates a dictionary. The 3 basic functions should be as followed: 
    •	insert a word
    •	delete a word
    •	search a word ( upto 3 starting letters like in original dictionary: for example if a word is “Philosophy”. User should be able to enter PHI and get all the words starting from PHI. It should also support 1 and 2 prefix characters)
 */

const readline = require("readline-sync");
console.log("Enter the length of dictionary: ");
let length = Number(readline.question());
function ReplicatedDictionary() {

    let dictionary = []
    let useDict = true;
    do {
        console.log("Enter 1 to insert, 2 to serach, 3 to delete and 0 to exit");
        var operation = Number(readline.question());
        switch (operation) {
            case 1:
                if (dictionary.length >= length) {
                    console.log("your dictionary is already filled, please delete some words!");
                }
                else {
                    dictionary = insert(dictionary)
                }

                break;
            case 2:
                console.log("Enter search term!");
                let search = String(readline.question());
                let searchLength = search.length
                for (var j = 0; j < length; j++) {
                    if (dictionary[j] != null) {
                        if (search.toString().toLowerCase() === dictionary[j].toString().toLowerCase().substring(0, searchLength)) {
                            console.log(dictionary[j]);

                        }

                    }
                }
                break;
            case 3:
                console.log("Enter delete term!");
                let del = String(readline.question());
                dictionary = dele(dictionary, del)
                break;

            case 0:
                useDict = false;
                break;

            default:
                console.log("Enter correct operation!");
                break;
        }
    } while (useDict)
}
function insert(dict) {
    console.log("Enter word to insert!");
    for (var l = 0; l < length; l++) {
        dict.push(String(readline.question()));
        console.log("word inserted!");
        return dict

    }

}
function dele(dict, searchItem) {
    for (var k = 0; k < length; k++) {
        if (dict[k]?.toString().toLowerCase() === searchItem.toString().toLowerCase()) {
            dict.splice(k, 1)
            console.log("word deleted!");
            return dict
        }
    }
    {
        console.log("word doesn't exist in dictionary!");
        return dict
    }

}
ReplicatedDictionary()

