/**Q#3: Write a function which will take an array as input and return the sum of two largest numbers in a n array.  For example, in array [3,7,1,5,11,19] the result would be 30 because 11 and 19 are largest numbers. */

const readline = require("readline-sync");
function SumOfLargest() {
    console.log("Enter size of array: ");
    let a = Number(readline.question());
    let myArr = [];
    console.log("Enter element of array: ");
    for (let i = 0; i < a; ++i) {
        myArr.push(Number(readline.question()));

    }
    let tem;
    for (let i = 0; i < myArr.length; i++) {
        for (let j = 0; j < myArr.length; j++) {
            if (myArr[j] < myArr[i]) {
                tem = myArr[i];
                myArr[i] = myArr[j];
                myArr[j] = tem;
            }
        }
    }
    let sum = myArr[0] + myArr[1];
    console.log("Result => ", sum);
}
SumOfLargest()

