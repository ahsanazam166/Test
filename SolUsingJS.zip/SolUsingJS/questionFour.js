/**Q#4: Write a function which will take an array as input and return an array with every missing element from 0 to highest entry. For example, in an array [3,4,9,1,7,3,2,6] the highest entry is 9 and missing numbers are [0,5,8] */

const readline = require("readline-sync");
function FindMissing() {
    console.log("Enter size of array: ");
    let a = Number(readline.question());
    let myArr = [];
    console.log("Enter element of array: ");

    for (let i = 0; i < a; ++i) {
        myArr.push(Number(readline.question()));

    }

    let tem;
    for (let i = 0; i < myArr.length; i++) {
        for (let j = 0; j < myArr.length; j++) {
            if (myArr[j] < myArr[i]) {
                tem = myArr[i];
                myArr[i] = myArr[j];
                myArr[j] = tem;
            }
        }
    }
    let newArr = []
    for (var j = 0; j<myArr[0]; j++) {
        if (!myArr.includes(j)) {
            newArr.push(j)

        }
    }
    console.log("Missing elements => ",newArr);
}
FindMissing()

