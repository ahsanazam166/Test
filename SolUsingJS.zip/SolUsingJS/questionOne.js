/**Q#1: Write a function which will take an array as input, sort and return the array in descending order. For example, if the array is [3,2,7,4,6,9] the result should be [9,7,6,4,3,2]. */

const readline = require("readline-sync"); 

function DescendingArray() {
    console.log("Enter size of array: ");
    let a = Number(readline.question());
    let myArr = [];
    console.log("Enter element of array: ");
    for (let i = 0; i < a; ++i) {
        myArr.push(Number(readline.question()));

    }
    console.log("Original Array => ", myArr);
    let tem;
    for (let i = 0; i < myArr.length; i++) {
        for (let j = 0; j < myArr.length; j++) {
            if (myArr[j] < myArr[i]) {
                tem = myArr[i];
                myArr[i] = myArr[j];
                myArr[j] = tem;
            }
        }
    }

    console.log("Sorted Array => ", myArr);
}
DescendingArray()

