/**Q#6: Write a function which will take an array as input, it will rotate the array to the right 1 time and return the rotated array. Rotation of the array means that each element is shifted right by one index. For example, the rotation of array A = [3,8,9,7,6] is [6,3,8,9,7] */

const readline = require("readline-sync");
function ArrayRotation() {
    console.log("Enter size of array: ");
    let a = Number(readline.question());
    let myArr = [];
    console.log("Enter element of array: ");

    for (let i = 0; i < a; ++i) {
        myArr.push(Number(readline.question()));

    }
    console.log("Original Array => ", myArr);
    length = myArr.length - 1
    var temp = myArr[length]
    for (var j = a - 1; j > 0; --j) {
        myArr[j] = myArr[j - 1]
    }
    myArr[0] = temp
    console.log("Rotated Array => ", myArr);
}

ArrayRotation()

