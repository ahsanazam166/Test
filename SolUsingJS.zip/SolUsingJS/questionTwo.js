/**Q#2: Write a function which will take a string as input, check and return if it is palindrome or not. For example, if the string is “madam” the function should return true and if the string is “doctor” it should return false. */

const readline = require("readline-sync");
function CheckPalindrome() {
    console.log("Enter String: ");
    let string = String(readline.question());
    var newStr=""
    for (var i = string.length-1; i >=0; --i) {
        newStr += string[i]
    }
    if(newStr==string){
        console.log("True");
    }
    else
    console.log("False");

}
CheckPalindrome()

