/**Q#5: Write a function which will take an array of numbers and return the number most repeated in the array with how many times it was repeated. For example, if the array is [4,3,5,6,4,7,9,2,4,6,3,4,6,3,4,8,5,1,5] the function should return 4 is repeated 5 times. */

const readline = require("readline-sync");
function MostRepeated() {
    console.log("Enter size of array: ");
    let n = Number(readline.question());
    let arr = [];
    console.log("Enter element of array: ");

    for (let i = 0; i < n; ++i) {
        arr.push(Number(readline.question()));

    }
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            if (arr[j] > arr[i]) {
                tem = arr[i];
                arr[i] = arr[j];
                arr[j] = tem;
            }
        }
    }
    let max_count = 1, res = arr[0];
    let curr_count = 1;

    for (let i = 1; i < n; i++) {
        if (arr[i] == arr[i - 1])
            curr_count++;
        else
            curr_count = 1;

        if (curr_count > max_count) {
            max_count = curr_count;
            res = arr[i - 1];
        }

    }
    console.log(res, "is repeated", max_count, "times");
}

MostRepeated()


