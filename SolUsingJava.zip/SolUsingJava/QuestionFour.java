import java.util.Scanner;

/**
 * Question#4: Write a function which will take an array as input and return an
 * array
 * with every missing element from 0 to highest entry. For example, in an array
 * [3,4,9,1,7,3,2,6] the highest entry is 9 and missing numbers are [0,5,8]
 */

public class QuestionFour {

    public static void printArray(int[] numberArray) {
        System.out.print("[");

        if (numberArray.length >= 1) {
            System.out.print(numberArray[0]);
        }

        for (int i = 1; i < numberArray.length; i++) {
            System.out.print(", " + numberArray[i]);
        }
        System.out.println("]");
    }

    public static int[] sortArray(int[] numberArray) {
        int temporaryVariable;
        for (int i = 0; i < numberArray.length; i++) {
            for (int j = 0; j < numberArray.length; j++) {
                if (numberArray[j] < numberArray[i]) {
                    temporaryVariable = numberArray[i];
                    numberArray[i] = numberArray[j];
                    numberArray[j] = temporaryVariable;
                }
            }
        }
        return numberArray;
    }

    public static boolean arrHasNum(int[] numberArray, int number) {
        for (int num : numberArray) {
            if (num == number) {
                return true;
            }
        }
        return false;
    }

    public static int removeDuplicates(int a[], int n) {
        if (n == 0 || n == 1) {
            return n;
        }
        int j = 0;
        for (int i = 0; i < n - 1; i++) {
            if (a[i] != a[i + 1]) {
                a[j++] = a[i];
            }
        }
        a[j++] = a[n - 1];
        return j;
    }

    public static int[] fillMissingNumbers(int[] arr) {
        int[] arrtmp = sortArray(arr);
        int arrSizeOfMissingNumbers = (arrtmp[0] + 1) - removeDuplicates(arr, arr.length);
        int[] missingNumbers = new int[arrSizeOfMissingNumbers];
        int counterAgainstArrSize = 0, number = 0;
        while (counterAgainstArrSize != arrtmp[0]) {
            if (!arrHasNum(arr, counterAgainstArrSize)) {
                missingNumbers[number] = counterAgainstArrSize;
                number++;
            }
            counterAgainstArrSize++;
        }
        return missingNumbers;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The Number Of Elements(Length Of Array)!");
        int length = input.nextInt();
        System.out.println("Enter Array Elements!");
        int[] array = new int[length];
        for (int i = 0; i < length; i++) {
            array[i] = input.nextInt();
        }
        System.out.println("Resulted Array!");
        printArray(fillMissingNumbers(array));
        input.close();
    }

}
