import java.util.Scanner;
/*Question#2: Write a function which will take a string as input, check and return if it is palindrome or not. For example, if the string is “madam” the function should return true and if the string is “doctor” it should return false. */

public class QuestionTwo {

    public static boolean palindrome(String s) {
        int sizehalf = (s.length() % 2 == 0) ? s.length() / 2 : (s.length() - 1) / 2;
        for (int i = 0, j = s.length() - 1; i < s.length() && j >= 0; i++, j--) {
            if (s.charAt(i) != s.charAt(j) && i != sizehalf) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The String That You Want To Check Whether It Is Palindrome Or Not!");
        String str = input.nextLine();
        System.out.println("Result!");

        System.out.println(palindrome(str));
        input.close();
    }
}
