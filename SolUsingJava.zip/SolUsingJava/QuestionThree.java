import java.util.Scanner;

/**
 * Question#3: Write a function which will take an array as input and return the
 * sum of
 * two largest numbers in a n array. For example, in array [3,7,1,5,11,19] the
 * result would be 30 because 11 and 19 are largest numbers.
 */

public class QuestionThree {

    public static void printArray(int[] numberArray) {
        System.out.print("[");

        if (numberArray.length >= 1) {
            System.out.print(numberArray[0]);
        }

        for (int i = 1; i < numberArray.length; i++) {
            System.out.print(", " + numberArray[i]);
        }
        System.out.println("]");
    }

    public static int[] sortArray(int[] numberArray) {
        int temporaryVariable;
        for (int i = 0; i < numberArray.length; i++) {
            for (int j = 0; j < numberArray.length; j++) {
                if (numberArray[j] < numberArray[i]) {
                    temporaryVariable = numberArray[i];
                    numberArray[i] = numberArray[j];
                    numberArray[j] = temporaryVariable;
                }
            }
        }
        return numberArray;
    }

    public static int sumOfTwoLargestNumbers(int[] arr) {
        int[] arrtmp = sortArray(arr);
        return arrtmp[0] + arrtmp[1];
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The Number Of Elements (Length Of Array)!");
        int length = input.nextInt();
        System.out.println("Enter Array Elements!");
        int[] array = new int[length];
        for (int i = 0; i < length; i++) {
            array[i] = input.nextInt();
        }
        System.out.println("Result!");
        System.out.println(sumOfTwoLargestNumbers(array));
        input.close();
    }

}
