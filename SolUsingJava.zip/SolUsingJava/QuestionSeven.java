import java.util.Scanner;

/**
 * Write a program in any language which replicates a dictionary. The 3 basic
 * functions should be as followed:
 * • insert a word
 * • delete a word
 * • search a word ( upto 3 starting letters like in original dictionary: for
 * example if a word is “Philosophy”. User should be able to enter PHI and get
 * all the words starting from PHI. It should also support 1 and 2 prefix
 * characters)
 */
public class QuestionSeven {

    public static void dictionary() {
        System.out.println("********  Please Create your Dictionary Here Of Specific Length   ********");
        int sizeOfDictionary;
        Scanner input = new Scanner(System.in);
        try {
            sizeOfDictionary = input.nextInt();
        } catch (Exception e) {
            System.out.println("Please Run Again And Enter Correct Size In Integers!");
            sizeOfDictionary = 0;
            input.close();
            return;
        }

        String search;
        String[] dictionaryArr = new String[sizeOfDictionary];
        for (int i = 0; i < dictionaryArr.length; i++) {
            dictionaryArr[i] = null;
        }
        boolean useDictionary = true;
        int operation;
        do {
            System.out.println("Please Press 1 To Insert, 2 To Search, 3 to Delete, and 0 To Exit Dictionary!");
            try {
                operation = input.nextInt();
            } catch (Exception e) {
                operation = 0;
            }
            switch (operation) {
                case 0:
                    useDictionary = false;
                    break;
                case 1:
                    dictionaryArr = insert(dictionaryArr);
                    break;
                case 2:
                    System.out.println("Enter Search Term!");
                    search = input.next();
                    search(dictionaryArr, search);
                    break;
                case 3:
                    System.out.println("Enter Delete Term!");
                    search = input.next();
                    dictionaryArr = delete(dictionaryArr, search);
                    break;
                default:
                    System.out.println("Please Select Correct Option!");
                    break;
            }
        } while (useDictionary);
        input.close();

    }

    public static String[] insert(String[] dict) {
        System.out.println("Enter Word To Insert!");
        Scanner input = new Scanner(System.in);
        String word;
        word = input.nextLine();
        for (int i = 0; i < dict.length; i++) {
            if (dict[i] == null) {
                dict[i] = word;
                System.out.println("Word Insered!");
                return dict;
            }
        }
        System.out.println("Your Dictionary Is Already Filled Please Delete Some Words!");
        input.close();
        return dict;

    }

    public static String[] delete(String[] arr, String searchTerm) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != null && arr[i].toLowerCase().equals(searchTerm.toLowerCase())) {
                arr[i] = null;
                System.out.println("Word Deleted!");
                return arr;
            }
        }
        System.out.println("Word Does Not Exists In Dictionary!");
        return arr;
    }

    public static void search(String[] arr, String searchTerm) {
        int searchSize = searchTerm.length();
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != null && searchTerm.toLowerCase().equals(arr[i].toLowerCase().substring(0, searchSize))) {
                System.out.println(arr[i]);
            }
        }
    }

    public static void main(String[] args) {
        dictionary();
    }

}
