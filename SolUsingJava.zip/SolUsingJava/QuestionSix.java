import java.util.Scanner;

/*Question#06: Write a function which will take an array as input, it will rotate the array to the right 1 time and return the rotated array. Rotation of the array means that each element is shifted right by one index. For example, the rotation of array A = [3,8,9,7,6] is [6,3,8,9,7]. */

public class QuestionSix {

    public static void printArray(int[] numberArray) {
        System.out.print("[");

        if (numberArray.length >= 1) {
            System.out.print(numberArray[0]);
        }

        for (int i = 1; i < numberArray.length; i++) {
            System.out.print(", " + numberArray[i]);
        }
        System.out.println("]");
    }

    public static int[] rotateArray(int[] arr) {
        int temp = arr[arr.length - 1];
        for (int i = arr.length - 1; i > 0; i--) {
            arr[i] = arr[i - 1];
        }
        arr[0] = temp;
        return arr;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The Number Of Elements (Length Of Array)!");
        int length = input.nextInt();
        System.out.println("Enter Array Elements!");
        int[] array = new int[length];
        for (int i = 0; i < length; i++) {
            array[i] = input.nextInt();
        }
        System.out.println("Original Array!");
        printArray(array);
        System.out.println("Resulted Array!");
        printArray(rotateArray(array));
        input.close();
    }

}
