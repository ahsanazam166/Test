import java.util.Scanner;

/**
 * Question#1: Write a function which will take an array as input, sort and
 * return the
 * array in descending order. For example, if the array is [3,2,7,4,6,9] the
 * result should be [9,7,6,4,3,2].
 * 
 */

public class QuestionOne {

    public static void printArray(int[] numberArray) {
        System.out.print("[");

        if (numberArray.length >= 1) {
            System.out.print(numberArray[0]);
        }

        for (int i = 1; i < numberArray.length; i++) {
            System.out.print(", " + numberArray[i]);
        }
        System.out.println("]");
    }

    public static int[] sortArray(int[] numberArray) {
        int temporaryVariable;
        for (int i = 0; i < numberArray.length; i++) {
            for (int j = 0; j < numberArray.length; j++) {
                if (numberArray[j] < numberArray[i]) {
                    temporaryVariable = numberArray[i];
                    numberArray[i] = numberArray[j];
                    numberArray[j] = temporaryVariable;
                }
            }
        }
        return numberArray;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The Number Of Elements (Length Of Array)!");
        int length = input.nextInt();
        System.out.println("Enter Array Elements!");
        int[] array = new int[length];
        for (int i = 0; i < length; i++) {
            array[i] = input.nextInt();
        }

        System.out.println("Original Array!");
        printArray(array);
        System.out.println("Sorted Array!");
        printArray(sortArray(array));
        input.close();

    }

}
