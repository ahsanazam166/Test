import java.util.Scanner;

/*
 * Question#05: Write a function which will take an array of numbers and return the
 * number most repeated in the array with how many times it was repeated. For
 * example, if the array is [4,3,5,6,4,7,9,2,4,6,3,4,6,3,4,8,5,1,5] the function
 * should return 4 is repeated 5 times.
 */

public class QuestionFive {

    public static void printArray(int[] numberArray) {
        System.out.print("[");

        if (numberArray.length >= 1) {
            System.out.print(numberArray[0]);
        }

        for (int i = 1; i < numberArray.length; i++) {
            System.out.print(", " + numberArray[i]);
        }
        System.out.println("]");
    }

    public static int[] sortArray(int[] numberArray) {
        int temporaryVariable;
        for (int i = 0; i < numberArray.length; i++) {
            for (int j = 0; j < numberArray.length; j++) {
                if (numberArray[j] < numberArray[i]) {
                    temporaryVariable = numberArray[i];
                    numberArray[i] = numberArray[j];
                    numberArray[j] = temporaryVariable;
                }
            }
        }
        return numberArray;
    }

    public static String numberFrequency(int[] arr) {
        int[] sortedArr = sortArray(arr);
        int count = 0, maxCount = 0, mostFrequentNumber = -1;
        for (int i = 1; i < sortedArr.length; i++) {
            if (sortedArr[i] == sortedArr[i - 1])
                count++;

            if (sortedArr[i] != sortedArr[i - 1] || i == sortedArr.length - 1) {
                if (count > maxCount) {
                    maxCount = count;
                    mostFrequentNumber = sortedArr[i - 1];
                }
                count = 1;
            }
        }
        return mostFrequentNumber + " Is Repeated " + maxCount + " Times In Array";
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter The Number Of Elements (Length Of Array)!");
        int length = input.nextInt();
        System.out.println("Enter Array Elements!");
        int[] array = new int[length];
        for (int i = 0; i < length; i++) {
            array[i] = input.nextInt();
        }

        System.out.println("Result!");
        System.out.println(numberFrequency(array));
        input.close();
    }
}